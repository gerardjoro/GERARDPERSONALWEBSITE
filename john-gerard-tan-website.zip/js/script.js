// John Gerard R. Tan — Personal Site
// Small, deliberate interactions: scroll reveal + active tab highlight.

document.addEventListener('DOMContentLoaded', function () {
  // Reveal elements as they enter the viewport
  var reveals = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && reveals.length) {
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });
    reveals.forEach(function (el) { observer.observe(el); });
  } else {
    reveals.forEach(function (el) { el.classList.add('is-visible'); });
  }

  // Mark the current page's nav tab as active
  var current = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.tabs-nav .nav-link').forEach(function (link) {
    var href = link.getAttribute('href');
    if (href === current) {
      link.classList.add('active');
      link.setAttribute('aria-current', 'page');
    }
  });

  // Simple contact form: build a mailto link instead of a real submit
  var form = document.getElementById('contact-form');
  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var name = document.getElementById('cf-name').value.trim();
      var email = document.getElementById('cf-email').value.trim();
      var message = document.getElementById('cf-message').value.trim();
      var subject = encodeURIComponent('Portfolio message from ' + (name || 'a visitor'));
      var body = encodeURIComponent(message + '\n\n— ' + name + ' (' + email + ')');
      window.location.href = 'mailto:johngerardtan555@gmail.com?subject=' + subject + '&body=' + body;
    });
  }
});
